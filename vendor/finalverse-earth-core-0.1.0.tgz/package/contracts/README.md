# Earth contracts 0.1.0

The executable TypeScript definitions and validators are in `sdk/typescript/src/index.ts`; the portable JSON schemas describe the same closed navigation and capability envelopes. Geographic axis order is explicit in JSON and latitude,longitude in geo URIs. Heights are WGS84 ellipsoid metres, never assumed orthometric heights. Dateline-crossing extents must use west > east deliberately; no implicit normalization occurs.

`vendor/spatial-resource.schema.json` is copied unchanged from SpatialDB 0.1.0, with SHA-256/source revision in `integration/compatibility.json`. It is the producer contract, not a new Earth entity standard. Existing SpatialDB schemas leave some numeric/domain semantics to the consumer; Earth additionally rejects invalid coordinate ranges, negative radius, private shared caching, mismatched identities and non-digest publication versions.

`earth.world-binding/v1` is an Earth consumer proposal, not an implemented MutSea/SpatialDB endpoint. Its anchor, ENU frame, heading, scale, world/region IDs, authority and immutable version are required and runtime-validated. World entry descriptors reference those authorities and explicitly require authorization; an advisory anchor never asserts transform calibration.

Compatibility: bump schema version for breaking changes; retain support while existing clients depend on it. Pin the packaged SDK and resource hash. Do not equate metadata compatibility with scene/asset renderer conformance. Language-independent upstream USAP vectors and recorded synthetic resource fixtures live under `conformance/fixtures`.
