# Finalverse Earth Core

The canonical product foundation for **Finalverse Earth — The AI-Native Living Earth**. Web, iOS, Android and Desktop share navigation contracts; their UI and rendering remain independent. This repository contains no renderer, database or world server.

## Develop

Node 24.14+ (24.x) or 26; CI pins 24.22.0. Dependencies are exact and locked.

```sh
npm ci --ignore-scripts
npm run check
npm run example
```

`npm run check` runs formatting, lint, strict TypeScript, SDK build, 12 executable tests and upstream contract hash verification. The validator is generated ahead of time for compatibility with browser CSP; consumers need no Ajv runtime or unsafe-eval. `npm audit --omit=dev --audit-level=high` checks production dependency exposure; security advisory availability is network-dependent.

The SDK is `@finalverse/earth-core@0.1.0`, exported from `sdk/typescript/dist`. Run `npm pack` after building to produce a versioned, self-contained consumer artifact. `private` prevents accidental registry publication. No publication/deployment is automatic.

```js
import {parseDestination, planNavigation} from '@finalverse/earth-core';
const destination = parseDestination('geo:45.5088,-73.554,28');
const navigation = planNavigation(destination, undefined, {
  schema_version: 'earth.client-capabilities/v1',
  representation_types: [], publication_kinds: [], world_authorities: []
});
```

For a live authorized SpatialDB resource, set `EARTH_SPATIALDB_ENDPOINT` and `SPATIALDB_TOKEN_FILE` (private local file), then run `node examples/navigation.mjs usap://spatialdb/entity/<uuid>`. The default example is explicitly a recorded synthetic fixture. It is not a real Montréal survey or a live world login.

Read [architecture](docs/architecture.md), [ecosystem/data audit](docs/audit.md), [acceptance](docs/acceptance.md), [contracts](contracts/README.md) and [roadmap](docs/roadmap.md).

## Living Earth handoff (0.2.0)

The additive [Living Earth contract](contracts/living-world.md) connects public geographic discovery to a reviewed native world destination. It pins world/binding/publication identities and preserves the original typed Earth destination for return. The envelope carries no login credential, session or capability. Existing navigation/resource contracts and producer pins remain compatible.

```sh
npm ci
npm run check
node examples/living-world.mjs
```

The example uses a public-discovery golden vector, validates it and prints navigation data. It does not sign in, launch an application or mutate a world. Native integration still requires normal authentication and authoritative binding verification. Earth Web and the existing Viewer consume the same closed handoff contract; the Viewer also tests the golden vector.
