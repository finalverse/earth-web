# Living Earth contracts 0.2.0

`earth.world-handoff/v1` is a renderer-neutral, credential-free navigation request. It composes the existing `earth.world-binding/v1`, `earth.world-entry/v1` and `earth.navigation/v1` contracts. MutSea-O's authenticated geographic binding is the runtime authority; discovery does not admit a user or authorize an edit.

The JSON schema describes the closed envelope. `validateLivingWorldHandoff` additionally enforces cross-field world/region identities, canonical region address, finite coordinates, exact immutable publication pins, native start bounds and an 8 KiB UTF-8 limit. Consumers must apply these semantic checks. The native Viewer and TypeScript SDK test the same public-discovery golden vector. Secrets, session IDs, capability URLs and arbitrary extra fields are refused.

The URI adapter is `finalverse:///app/living_earth/open?request=<percent-encoded JSON>`. It opens a review, then the existing native grid/login flow. An entry point uses WGS84 longitude/latitude/ellipsoid height; native standing coordinates are explicit region-local ENU metres. The publication pin separately names its WGS84 origin, EUS axes, graph, immutable version, root digest and frame ID. Publication identity is not mutable world-state identity.

`regionToEcef` preserves the complete authoritative clockwise heading and uniform scale; matrices are column-major f64. Native ENU and published EUS are never interchanged by changing labels. Consumers compare the supplied runtime transform against the binding and against the publication's frame before composing geometry. Orthometric terrain requires its producer's geoid normalization; no datum correction is guessed here.

Return uses the original `return_to.destination`, including the clicked geographic height, at `<origin>/#earth_return=<encoded earth.navigation/v1>`. The HTTPS/loopback origin carries no credential or native capability. Returning does not log out or transfer a session. A browser can require a fresh publication read credential. Navigating elsewhere in the world must not silently overwrite the original destination.

Compatibility: all 0.1.x navigation/resource schemas and producer pins are retained. The new envelope and validators are additive in SDK 0.2.0. `opensim.login/v1` is a connection adapter identifier, not a universal world protocol. Future runtimes introduce a versioned adapter while retaining this navigation/identity envelope. The current world-binding consumer names the existing `mutsea` authority; extending authorities requires an explicit compatible contract revision.
